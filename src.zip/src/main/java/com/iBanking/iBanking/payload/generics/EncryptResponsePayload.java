package com.iBanking.iBanking.payload.generics;

import lombok.Data;

@Data
public class EncryptResponsePayload {
    private String request;
}
