package com.iBanking.iBanking.payload.generics;

import lombok.Data;

@Data
public class DecryptRequestPayload {
    private String response;
}
