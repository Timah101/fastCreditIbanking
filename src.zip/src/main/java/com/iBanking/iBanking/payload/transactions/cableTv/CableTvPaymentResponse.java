package com.iBanking.iBanking.payload.transactions.cableTv;

import lombok.Data;

@Data
public class CableTvPaymentResponse {
    private String responseCode;
    private String responseMessage;

}
