package com.iBanking.iBanking.payload.generics;

import lombok.Data;

@Data
public class AccessTokenResponsePayload {
    private String ACCESS_TOKEN;
}
